# CSD213 Test2B
## Food Reservation HTML | JS

![Working Sample](./sample.gif)
- [x] Name validation
- [x] Phone validation
- [x] Error messages for Name & Phone appears indicating error
- [x] Time radio button fixed
- [x] Food option validation
- [x] Submission disables on invalid inputs
- [x] Submission enables on all valid inputs
- [x] Submission message confirmation appears when successful